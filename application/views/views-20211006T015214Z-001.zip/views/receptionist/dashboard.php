<br />

<div class="container">
  <div class="row">
    <div class="col-sm-12">

      <?php $this->load->view($dashboard_new_enquiry); ?>

    </div> <!--Col 12-->
  </div> <!--Row-->
</div> <!--Container Fluid-->